<?php
/**
 * Created by PhpStorm.
 * User: ricar
 * Date: 06/07/2018
 * Time: 21:19
 */

namespace aluno;


class Aluno
{
    $aluno = [];
}