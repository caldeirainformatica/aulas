<?php

namespace App\Http\Controllers;

use App\Aluno;
use Illuminate\Http\Request;

class AlunoController extends Controller
{
    public function getAlunos()
    {
        $alunos = Aluno::all();
        return view('aluno/list', compact('alunos'));
    }

    public function salvarAluno(Request $request)
    {
        if ($request->id_aluno) {
            Aluno::find($request->id_aluno)->update($request->input());
        } else {
            Aluno::create($request->input());

        }
        return redirect()->route('aluno.list');
    }

    public function deletarAluno($id)
    {
        Aluno::find($id)->delete();
        return redirect()->route('aluno.list');
    }

    public function alterarAluno()
    {

    }

    public function form($id = "")
    {
        $aluno = new Aluno();
        if ($id) {
            $aluno = Aluno::find($id);
            return view('aluno/form', compact('aluno'));
        }
        return view('aluno/form', compact('aluno'));

    }
}
