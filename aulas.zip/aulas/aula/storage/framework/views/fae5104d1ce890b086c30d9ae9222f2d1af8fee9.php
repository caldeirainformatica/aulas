<div align="center">
    <span>Listagem de Alunos</span>
</div>
<div>
    <a href="<?php echo e(route('aluno.form')); ?>">Add</a>
    <table id="tabela" align="center" border="line">
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Sobrenome</th>
            <th>Curso</th>
            <th>Semestre</th>
            <th colspan="2">Ações</th>
        </tr>
        <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($aluno->id_aluno); ?></td>
                <td><?php echo e($aluno->tx_nome); ?></td>
                <td><?php echo e($aluno->tx_sobrenome); ?></td>
                <td><?php echo e($aluno->tx_curso); ?></td>
                <td><?php echo e($aluno->nu_semestre); ?></td>
                <td><a href="<?php echo e(route("aluno.deletar", $aluno->id_aluno)); ?>">Excluir</a></td>
                <td><a href="<?php echo e(route("aluno.form", $aluno->id_aluno)); ?>">Alterar</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>