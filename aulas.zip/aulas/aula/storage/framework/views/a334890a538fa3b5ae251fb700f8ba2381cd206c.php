<form method="post" action="<?php echo e(route('aluno.salvarAluno')); ?>">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <input type="hidden" name="id_aluno" value="<?php echo e($aluno->id_aluno); ?>">
    <input type="text" name="tx_nome" placeholder="Nome" value="<?php echo e($aluno->tx_nome); ?>">
    <input type="text" name="tx_sobrenome" placeholder="Sobrenome" value="<?php echo e($aluno->tx_sobrenome); ?>">
    <input type="text" name="tx_curso" placeholder="curso" value="<?php echo e($aluno->tx_curso); ?>">
    <input type="number" name="nu_semestre" placeholder="Semestre" value="<?php echo e($aluno->nu_semestre); ?>">
    <button type="submit">Submit</button>
</form>